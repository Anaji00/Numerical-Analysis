import math

def f(x):
    # Function to integrate
    return math.sin(x)

def romberg_integration(f, a, b, max_iter=10):
    """
    Perform Romberg integration to approximate the integral of f from a to b.

    Parameters:
    f (function): The function to integrate.
    a (float): The lower limit of integration.
    b (float): The upper limit of integration.
    max_iter (int): The maximum number of iterations (default is 10).

    Returns:
    float: The approximated integral of f from a to b.
    """
    
    # Initialize the Romberg table
    R = [[0] * max_iter for _ in range(max_iter)]

    # Initial trapezoidal rule estimate
    h = b - a
    R[0][0] = (h / 2) * (f(a) + f(b))

    for i in range(1, max_iter):
        # Halve the step size
        h /= 2

        # Composite trapezoidal rule
        sum_trap = sum(f(a + (2*k - 1) * h) for k in range(1, 2**i))
        R[i][0] = 0.5 * R[i-1][0] + sum_trap * h

        # Richardson extrapolation
        for j in range(1, i + 1):
            R[i][j] = R[i][j-1] + (R[i][j-1] - R[i-1][j-1]) / (4**j - 1)

    # Return the most accurate estimate and the Romberg table
    return R[max_iter-1][max_iter-1], R

# Example usage
a = 0  # Lower limit of integration
b = math.pi  # Upper limit of integration
integral, romberg_table = romberg_integration(f, a, b)

print(f"Approximated integral: {integral}")
print("Romberg table:")
for row in romberg_table:
    print(row)
